#############installing packages###############
##########By Prahar, Rohit, Rusheel#############
#install.packages(c("psych", "GPArotation"), dependencies= TRUE)
library(tidyr)
library(dplyr)
#install.packages("tidyverse")
library(tidyverse)
#install.packages("corrplot")
library(corrplot)
library(GPArotation)

##############Loading dataset############
ds <- read.csv("test.csv")

str(ds)
###########
############Check which variables have missing values
missing_values <- colSums(is.na(ds))
missing_variables <- names(ds)[missing_values > 0]
missing_varaibles

##################
#arrival delay has a lot of missing values lets check the distribution of it
###########Replacing the missing values #########################

###############distribution of Arrival dealy#################
hist(ds$Arrival.Delay.in.Minutes, main = "Distribution of Arrival Delay in Minutes", xlab = " Dleay in Minutes")
###################################

##################Before removing na values let check the summary statistics##############

summary(ds)
summary(ds$Arrival.Delay.in.Minutes)

###################################### #Replacing the na values with median##########################
median_arrival_delay <- median(ds$Arrival.Delay.in.Minutes, na.rm = TRUE)
ds$Arrival.Delay.in.Minutes[is.na(ds$Arrival.Delay.in.Minutes)] <- median_arrival_delay

############################################# Plotting histogram########################

library(ggplot2)
library(tidyr)
library(dplyr)

# Plot histograms to visualize the distribution of each numeric variable
pdf("histograms_numeric_vars.pdf", width = 14, height = 8.5)
ds %>%
       select_if(is.numeric) %>%
       gather() %>%
       ggplot(aes(value)) +
       geom_histogram(fill = "purple", color = "black") +
       facet_wrap(~ key, scales = "free") +
       ggtitle("Histogram of Numeric Variables") +
       xlab("Value") +
       ylab("Frequency") +
       theme(axis.text.x = element_text(angle = 90, hjust = 1, vjust = 0.5))
dev.off()

############### plotting boxplot###########################
library(ggplot2)
library(tidyr)

# Select only the numeric columns from the dataset and remove the ID column
ds_num <- select_if(ds, is.numeric) %>% select(-id)

# Reshape the data for plotting
ds_num_p <- ds_num %>% gather(variable, values, 1:18)

# Set the plot dimensions
options(repr.plot.width = 14, repr.plot.height = 8)

# Create the boxplot
p <- ggplot(ds_num_p) +
       geom_boxplot(aes(x=variable, y=values), fill="cadetblue") + 
       facet_wrap(~variable, ncol=6, scales="free") + 
       theme(strip.text.x = element_blank(), text = element_text(size=14))

# Save the plot to a PDF file
ggsave("boxplot.pdf", p, width = 14, height = 8, units = "in")

##########################ouliter detection###################3

#here flight.distance variable has few outlier before replacing it lets check for the distribution of this varaible.

hist(ds$Flight.Distance, main = "Distribution of Flight Distance", xlab = "Flight Distance", breaks = seq(0, 10000, by = 100))
#########################################################
# Calculate interquartile range (IQR) and Tukey's limits for Flight.Distance
Q1 <- quantile(ds$Flight.Distance, 0.25)
Q3 <- quantile(ds$Flight.Distance, 0.75)
IQR <- Q3 - Q1
lower <- Q1 - 1.5*IQR
upper <- Q3 + 1.5*IQR

##################Identify and remove outliers using Tukey's method###############3
outliers <- which(ds$Flight.Distance < lower | ds$Flight.Distance > upper)
ds <- ds[-outliers, ]
#In this code, quantile() is used to calculate the first and third quartiles of the Flight.Distance variable, from which the interquartile range (IQR) is computed. The Tukey's limits for outliers are then calculated as lower = Q1 - 1.5*IQR and upper = Q3 + 1.5*IQR. Finally, the which() function is used to identify the indices of outliers, which are then removed from the data frame df using the negative index notation df[-outliers, ].

##########################
ds_num<-select_if(ds,is.numeric)%>%select(-id)
ds_num_p<-ds_num %>% gather(variable,values,1:18 )
options(repr.plot.width = 14, repr.plot.height = 8)
ggplot(ds_num_p)+
       geom_boxplot(aes(x=variable,y=values),fill="cadetblue") + 
       facet_wrap(~variable,ncol=6,scales="free") + 
       theme(strip.text.x = element_blank(),
             text = element_text(size=14))
############################summary statistic for departue delay#######################
#Summary stastistic for departue delay in minutes

# summary statistics
summary(ds$Departure.Delay.in.Minutes)

# histogram
hist(ds$Departure.Delay.in.Minutes, breaks = 30, col = "lightblue")


######################### Removing outlier form Departue delay in minutes###################
#Removing outlier from the departure delay variable.

# Load the necessary packages
library(dplyr)

# Calculate the interquartile range
Q1 <- quantile(ds$Departure.Delay.in.Minutes, 0.25)
Q3 <- quantile(ds$Departure.Delay.in.Minutes, 0.75)
IQR <- Q3 - Q1

# Calculate the lower and upper bounds for outliers using Tukey's method
LB <- Q1 - 1.5 * IQR
UB <- Q3 + 1.5 * IQR

# Remove outliers using the lower and upper bounds
ds<- ds %>% filter(Departure.Delay.in.Minutes >= LB & Departure.Delay.in.Minutes <= UB)

#Observations  This code calculates the interquartile range (IQR) of the Departure.Delay.in.Minutes variable and then calculates the lower bound (LB) and upper bound (UB) for outliers using Tukey's method. Finally, it removes the outliers from the dataframe by filtering rows where the Departure.Delay.in.Minutes variable is within the lower and upper bounds.

####################### Plot bar charts to visualize the frequency of each categorical variable#################################3
#Plot bar charts to visualize the frequency of each categorical variable
ds %>%
       select_if(is.character) %>%
       gather() %>%
       ggplot(aes(value)) +
       geom_bar(fill = "wheat4") + 
       labs(x = "Values", y = "Frequency", title = "Vertical Bar Plot with Labels") +
       theme(axis.text.x = element_text(angle = 90, hjust = 1, vjust = 0.5))

###############################making satisfaction as yes or no#####################################
#In addition to that,  we have to ensure that the level of "yes" is 1 and "No" is 2, and then to replace the missing values in arrival_delay_in_minutes with the mean of itself, and convert the character variables to a factor for building a model.

airline_satisfaction <- airline_satisfaction %>%
       mutate(across(where(is.character), ~ as.factor(str_squish(str_to_title(.))))) %>%
       mutate(
              satisfaction = str_replace_all(satisfaction, "neutral Or dissatisfied", replacement = "No"),
              satisfaction = str_replace_all(satisfaction, "satisfied", replacement = "Yes"),
              satisfaction = factor(satisfaction, levels = c("Yes", "No"))
       )


################Tree plot for distribution analysis#############
#The strings are converted to title case, The labels converted to "Yes" and "No" We changed the levels of the labels to be suitable to Tidymodels framework "Yes" is 1 and "No" is 2. we replaced the NA's in arrival_delay_in_minutes to the mean of it.
#Tree Plot Function

tree_plot <- function(var_to, pal = "Set1") {
       
       for_title <- as_label(enquo(var_to))
       for_title <- str_to_title(str_replace_all(for_title, "_", " "))
       airline_satisfaction %>% 
              count({{var_to}}, sort = T) %>%
              mutate(prop = str_c(round(n / sum(n) * 100, 0), "%"),
                     label = str_c({{var_to}}, " ", prop)) %>%
              treemap(
                     index = "label",
                     vSize = "n",
                     type = "index",
                     title = glue(for_title," Proportions"),
                     palette = pal,
                     border.col = c("black"),
                     border.lwds = 1,
                     fontsize.labels = 18
              )
}


######################Treeplot for customer type#################3


#tree_plot(Customer_Type, pal = c("#F7495D", "#5FB9E7"))

##########Distribution of Flight Distance################
airline_satisfaction %>% 
       select(Flight_Distance) %>% 
       ggplot(aes(Flight_Distance)) +
       geom_histogram(color = "#0E1856", fill = "#0E1856", bins = 40, alpha = 0.5) +
       geom_vline(aes(xintercept = mean(Flight_Distance)), color = "#FD6041", size = 1) +
       
       labs(
              title = "Flight Distance Distributions",
              subtitle = "Histogram Plot",
              caption = "Data Source: Airline Passenger Satisfaction Predictive Analysis",
              x = "Flight Distance",
              y = "Count"
       )


###########Line plot for flight distance with age###########3

##### Flight Distance and Age
airline_satisfaction %>%
       select(Gender, Age, satisfaction) %>% 
       count(Gender, Age, satisfaction) %>% 
       arrange(desc(Age)) %>% 
       ggplot(aes(x = Age, y = n)) +
       geom_line(aes(color = Gender), size = 1) +
       facet_wrap(vars(satisfaction))+
       geom_rug(color = "#730185") +
       scale_color_manual(values = c( "Female" = "#E60088", "Male" = "#0074BB"))+
       theme(strip.background = element_rect(fill = "#673B38"),
             strip.text = element_text(face = "bold")) +
       labs(
              title = "Salisfaction by Flight Distance and Age",
              x = "Age",
              y = "Count",
              color = NULL
       )

##############Distribution of age wth respect to male and female##########

#airline_satisfaction %>%
# select(Age, Gender) %>%  
#arrange(desc(Age)) %>% 
#mutate(age_group = case_when(
#                             Age >= min(Age) & Age <= 10 ~ glue(min(Age)," -10"),
#                            Age > 10 & Age <= 18 ~ "11-18",
#                           Age > 18 & Age <= 25 ~ "18-25",
#                          Age > 25 & Age <= 35 ~ "26-35",
#                         Age > 35 & Age <= 45 ~ "36-45",
#                        Age > 45 & Age <= 50 ~ "46-50",
#                       Age > 50 & Age <= 64 ~ "51-64",        
#                      Age > 64 ~ "> 64"
#                   ),
#age_group = factor(
# age_group,
#level = c(glue(min(Age)," -10"), "11-18","18-25", "26-35", "36-45", "46-50", "51-64", "> 64")
#)
#) %>% 
#count(age_group, Gender, name = "counts") %>% 
#mutate(perct = round(counts/sum(counts),2)) %>% 
#ggplot(aes(x = age_group, y = counts)) +
#geom_col(aes(fill = Gender), size = 1) +
#scale_fill_manual(values = c( "Female" = "#40615d", "Male" = "#ebcf34"))+
#labs(
# title = "Satisfaction by Flight Distance and Age",x = "Age",
#y = "Count",
#fill = NULL
#)

###############linear regression###################

lm_mod_arr_flight_departure <- lm(Arrival_Delay_in_Minutes ~ Departure_Delay_in_Minutes, data = airline_satisfaction)

summary(lm_mod_arr_flight_departure)


lm_mod_arr_flight_distance <- lm(Arrival_Delay_in_Minutes ~ Flight_Distance, data = airline_satisfaction)

summary(lm_mod_arr_flight_distance)
##########################################scatterplot for flight distance and delays scatter plot##################33
#Flight distance and Delays scatter plot
airline_satisfaction_index <- initial_split( airline_satisfaction, prop = 2/3, strata = satisfaction)
arrival_depart_delay_for_plot <- testing(airline_satisfaction_index)

arrival_delay <- arrival_depart_delay_for_plot %>%
       select(Flight_Distance, Arrival_Delay_in_Minutes) %>% 
       ggplot(aes(x = Flight_Distance, y = Arrival_Delay_in_Minutes)) +
       geom_point( size = 1) +
       geom_rug(color = "#730185") +
       scale_x_log10() +
       theme(strip.background = element_rect(fill = "#673B38"),
             strip.text = element_text(face = "bold")) +
       labs(
              title = "Filght distance and Arrival Delays",
              x = " Flight Distance" ,
              y = "Arrival Delays/min",
              fill = ""
       )




depart_delay <- arrival_depart_delay_for_plot %>%
       select(Flight_Distance, Departure_Delay_in_Minutes) %>% 
       ggplot(aes(x = Flight_Distance, y = Departure_Delay_in_Minutes)) +
       geom_point(size = 1) +
       geom_rug(color = "#730185") +
       scale_x_log10() +
       theme(strip.background = element_rect(fill = "#673B38"),
             strip.text = element_text(face = "bold")) +
       labs(
              title = "Filght distance and Departure Delays",
              x = " Flight Distance" ,
              y = "Departure Delays/min",
              fill = ""
       )

arrival_delay + depart_delay


##########################Fitting linear regression line#################
# Plot the regression line
ggplot(airline_satisfaction, aes(x = Departure_Delay_in_Minutes, y = Arrival_Delay_in_Minutes)) +
       geom_point() +
       geom_smooth(method = "lm", se = FALSE)


############################Barplot for online boarding vs satisfaction####
table_boarding <- tableGrob(airline_satisfaction %>% 
                                   select(Online_boarding, satisfaction) %>%  
                                   count(Online_boarding, satisfaction), theme = ttheme_minimal())


airline_satisfaction %>% 
       select(Online_boarding, satisfaction) %>%  
       count(Online_boarding, satisfaction) %>% 
       ggplot(aes(x = Online_boarding, y = n, fill = satisfaction)) +
       geom_col(size = 1) +
       scale_fill_manual(values = c("#264a59", "#9158b0"))+
       theme(strip.background = element_rect(fill = "#673B38"),
             strip.text = element_text(face = "bold")) +
       labs(
              title = "Online boarding vs Satisfaction",
              x = "Online boarding" ,
              y = "Count",
              fill = ""
       ) + table_boarding


########################Satisfaction by seat comfort and class###############

airline_satisfaction %>% 
       select(Seat_comfort, satisfaction, Class) %>%  
       count(Seat_comfort, satisfaction, Class) %>% 
       ggplot(aes(x = Seat_comfort, y = n, fill = satisfaction)) +
       geom_col(size = 1) +
       scale_fill_manual(values = c("#7d9669", "#453d2a"))+
       facet_wrap(vars(Class))+
       theme(strip.background = element_rect(fill = "#673B38"),
             strip.text = element_text(face = "bold")) +
       labs(
              title = "Satisfaction by Seat Comfort and Class",
              x = "Seat_comfort" ,
              y = "Count",
              fill = ""
              
       )

###############Satisfaction by departure arrival time convenient and class

airline_satisfaction %>% 
       select(Departure.Arrival_time_convenient, satisfaction, Class) %>%  
       count(Departure.Arrival_time_convenient, satisfaction, Class) %>% 
       ggplot(aes(x = Departure.Arrival_time_convenient, y = n, fill = satisfaction)) +
       geom_col(size = 1) +
       scale_fill_manual(values = c("#c3c746", "#450f5e"))+
       facet_wrap(vars(Class))+
       theme(strip.background = element_rect(fill = "#673B38"),
             strip.text = element_text(face = "bold")) +
       labs(
              title = "Satisfaction by Departure Arrival Time Convenient and Class",
              x = "Seat Comfort" ,
              y = "Count",
              fill = ""
       ) 

##############Predictive Analytics Modelling###################################
#################Conversion of binary varaible to yes or no####################
airline_satisfaction <- airline_satisfaction %>%
       mutate(across(where(is.character), ~ as.factor(str_squish(str_to_title(.))))) %>%
       mutate(
              satisfaction = str_replace_all(satisfaction, "Neutral Or Dissatisfied", replacement = "No"),
              satisfaction = str_replace_all(satisfaction, "Satisfied", replacement = "Yes"),
              satisfaction = factor(satisfaction, levels = c("Yes", "No")),
              
       ))
)

glimpse(airline_satisfaction)

#####################################################
############Logistic regression######################Research Questions 1
######model data frame###############
airline_satisfaction_for_model <- airline_satisfaction %>%
       select(-c(
              id,
              sr
       )) 

######################data split##############

set.seed(31967)

airline_satisfaction_split <- initial_split( airline_satisfaction_for_model, prop = 3/4, strata = satisfaction)

train_data <- training(airline_satisfaction_split)
test_data  <- testing(airline_satisfaction_split)
###########################################

#######################Training and testing set proportions by attrition##################
train_data %>% 
       count(satisfaction) %>% 
       mutate(prop = n/sum(n))

######################
test_data  %>% 
       count(satisfaction) %>% 
       mutate(prop = n/sum(n))


##########Genrate 10 folds####################
set.seed(31967)
fold_cv <- vfold_cv(train_data, times = 10, apparent = TRUE)

###########First Model: Penalized Logistic Regression
#####Build the model (glmnet)
logis_mod <- 
       logistic_reg(penalty = tune(), mixture = 1) %>% 
       set_engine("glmnet")
######Create the recipe (glmnet)############

logis_recipe <-
       recipe(satisfaction ~ ., data = train_data) %>%
       step_dummy(all_nominal_predictors(), -all_outcomes()) %>%
       step_zv(all_numeric()) %>%
       step_normalize(all_numeric()) %>% 
       step_corr(all_numeric_predictors(), threshold = .7)

# summary(logis_recipe)

##########Create the workflow (glmnet)############

logis_workflow <- 
       workflow() %>% 
       add_model(logis_mod) %>% 
       add_recipe(logis_recipe)


#########Create the Grid (glmnet)#########

logis_reg_grid <- tibble(penalty = 10^seq(-3, -1, length.out = 60))
logis_reg_grid %>% top_n(-5) 


######Train and tune the model (glmnet)#####3
set.seed(31967)
logis_res <- 
       logis_workflow %>% 
       tune_grid(fold_cv,
                 grid = logis_reg_grid,
                 control = control_grid(save_pred = TRUE),
                 metrics = metric_set(roc_auc))
##########Plot the area under the ROC VS penalty value (glmnet)########
logis_plot <- 
       logis_res %>% 
       collect_metrics() %>% 
       ggplot(aes(x = penalty, y = mean)) + 
       geom_point() + 
       geom_line() + 
       scale_x_log10(labels = scales::label_number()) +
       theme(
              plot.background = element_rect(fill = "#FFF1B2")) +
       labs(
              title = "Area under the ROC Curve",
              x= "Penalty",
              y = "Area under the ROC Curve"
              
       )

logis_plot 

###############Find top 20 models#########3
top20_models <-
       logis_res %>% 
       show_best("roc_auc", n = 40) %>% 
       arrange(desc(mean))

###########set the best model###########3
logis_best <- 
       logis_res %>% 
       show_best() %>% 
       arrange(desc(mean)) %>%
       dplyr::slice(2)

logis_best
top20_models


##############Roc Curve##########
logis_auc <- 
       logis_res %>% 
       collect_predictions(parameters = logis_best) %>% 
       roc_curve(satisfaction, .pred_Yes) %>% 
       mutate(model = "Logistic Regression")
autoplot(logis_auc)

##########Final logistic regresion Fit##########
set.seed(31967)
final_logis_res <-
       logis_workflow %>%
       finalize_workflow(logis_best) %>%
       last_fit(airline_satisfaction_split)

final_logis_res

###########Confusion matrix#########
confusion_matrix_logis <- collect_predictions(final_logis_res) %>%
       conf_mat(satisfaction, .pred_class)


##################Random Forest###########Research Questions 2#######

Create the RF Recipe
rf_rec <- 
       recipe(satisfaction ~ ., data = train_data) %>%
       step_dummy(all_nominal_predictors()) %>%
       step_zv(all_numeric()) %>%
       step_normalize(all_numeric()) 

# rf_rec %>% prep() %>%
# juice() %>% select(satisfaction) %>% table()
# summary(rf_rec)

#############################Build the RF Model##########33
rf_mod <- 
       rand_forest(mtry = tune(), 
                   min_n = tune(),
                   trees = tune()
       ) %>% 
       set_engine("ranger",  importance = "impurity") %>% 
       set_mode("classification")
############################Create the RF worklow###########3
rf_workflow <- 
       workflow() %>% 
       add_model(rf_mod) %>% 
       add_recipe(rf_rec) 
####################Train and tune the RF model###########
Let’s use grid = 10 without thinking of the best values of mtry, min_n and trees.

set.seed(31967)
rf_res <- 
       rf_workflow %>% 
       tune_grid(fold_cv,
                 grid = 10,
                 control = control_grid(save_pred = TRUE),
                 metrics = metric_set(roc_auc))
#####################Find the best RF Model###############
rf_res %>% 
       show_best(metric = "roc_auc")

#################Select the best RF Model#############
rf_best <- 
       rf_res %>% 
       select_best(metric = "roc_auc")
rf_best


###################Finalize RF workflow################33
finalize_workflow(
       rf_workflow,
       rf_best
)

###################Create the ROC Curve Data###########3
rf_auc <- 
       rf_res %>% 
       collect_predictions(parameters = rf_best) %>% 
       roc_curve(satisfaction, .pred_Yes) %>% 
       mutate(model = "Random Forest")
#############Confusion Matrix RF############
collect_predictions(final_rf_fit) %>%
       conf_mat(satisfaction, .pred_class) %>%
       pluck(1) %>%
       as_tibble() %>%
       ggplot(aes(Truth, Prediction, alpha = n)) +
       geom_tile(show.legend = FALSE, fill = "orange") +
       geom_text(aes(label = n), colour = "#2F423D", alpha = 1, size = 7) +
       scale_x_discrete(position = "top", limits = c("Yes","No"))


#############Final RF ROC Curve###################3
final_rf_auc <- 
       rf_res %>% 
       collect_predictions(parameters = rf_best) %>% 
       roc_curve(satisfaction, .pred_Yes)



final_rf_auc %>%
       ggplot(aes(x = 1 - specificity, y = sensitivity)) +
       geom_path(lwd = 1.5, alpha = 0.8, color = "#263F75") +
       geom_abline(lty = 3) +
       coord_equal() +
       theme(
              legend.position = "top",
              plot.background = element_rect(colour = "steelblue", fill = "#B6C99B"),
              panel.background = element_rect(colour = "steelblue", fill = "#E8F0DC"),
              plot.title.position = "panel",
              plot.title = element_text(
                     size = 18,
                     hjust = 0.5,
                     color = "#010FCC"
              ),
              plot.subtitle = element_text(size = 8),
              plot.caption.position = "plot",
              plot.caption = element_text(size = 10, color = "grey"),
              axis.ticks.x = element_blank(),
              axis.text = element_text(size = 10, color = "black"),
              axis.title = element_text(size = 10, color = "black")
       ) +
       labs(
              title = "Final ROC Curve (Random Forest)",
              x = "False Positive Rate (1-Specificity)",
              y = "True Positive Rate (Sensitivity)",
              color = NULL
       )

###########################Plot Variable Importance#################
final_rf_fit %>% 
       pluck(".workflow", 1) %>%   
       pull_workflow_fit() %>%
       vip(num_features = 20, geom = "col", horizontal = TRUE, 
           aesthetics = list(color = "black", fill = "#1F6CA2", size = 0.5)) +
       theme(
              plot.background = element_rect(fill = "white"),
              plot.title.position = "panel",
              plot.title = element_text(size = 18, hjust = 0.5),
              plot.caption.position = "plot",
              plot.caption = element_text(size = 8, color = "grey"),
              panel.background = element_rect(fill = "#C9D4C7"),
              panel.grid = element_blank(),
              axis.ticks.x = element_blank(),
              axis.text = element_text(size = 12),
              axis.title = element_text(size = 14)
       ) +
       labs(
              title = "Variable Importance",
              caption = "Data Source: Kaggle IBM HR Employee Attrition",
              x = "Variables",
              y = "Importance"
       )

#########################Clustering ##########################################################

# Load required libraries
library(cluster)
library(factoextra)

# Select relevant variables for cluster analysis
facilities <- ds[, c("Inflight.wifi.service", "Food.and.drink", "Online.boarding",
                     "Seat.comfort", "Inflight.entertainment", "On.board.service",
                     "Leg.room.service", "Baggage.handling", "Checkin.service",
                     "Inflight.service", "Cleanliness")]

# Preprocess the data (if needed)

# Scale the numeric variables
scaled_data <- scale(facilities)

# Perform cluster analysis using the elbow method
set.seed(123)
k <- 1:10
wss <- sapply(k, function(k) {
       kmeans(scaled_data, centers = k, nstart = 10)$tot.withinss
})

# Plot the elbow curve
plot(k, wss, type = "b", pch = 19, frame = FALSE, xlab = "Number of Clusters",
     ylab = "Total Within Sum of Squares", main = "Elbow Method")

# Determine the optimal number of clusters using the elbow method
fviz_nbclust(facilities, kmeans, method = "wss")


#############Clustering Visualisations################
# Perform k-means clustering with the optimal number of clusters
set.seed(123)
k <- 4  # Replace with the optimal number of clusters
kmeans_model <- kmeans(scaled_data, centers = k, nstart = 10)

# Add cluster assignment to the dataset
facilities$Cluster <- as.factor(kmeans_model$cluster)

# Visualize the clusters using PCA (Principal Component Analysis)
pca <- prcomp(scaled_data, scale = TRUE)
pca_data <- data.frame(PC1 = pca$x[, 1], PC2 = pca$x[, 2], Cluster = facilities$Cluster)

# Plot the clusters
library(ggplot2)
ggplot(pca_data, aes(x = PC1, y = PC2, color = Cluster)) +
       geom_point(size = 3) +
       scale_color_discrete(name = "Cluster") +
       labs(x = "PC1", y = "PC2", title = "Cluster Analysis - Satisfaction over Facilities")
###########################################################
