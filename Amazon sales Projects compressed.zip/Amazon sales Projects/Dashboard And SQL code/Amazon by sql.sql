Use amazon;
#1. Merging the amazon_sale_report , international_sale_report, sale-report datasets from amazon database 

Select * 
FROM amazon_sale_report INNER JOIN international_sale_report 
ON amazon_sale_report.SKU = international_sale_report.SKU
INNER JOIN sale_report ON international_sale_report.SKU = sale_report.`SKU Code`;

#2. Utilising the amazon merged datasets
#  What all appreals are famous within the city of India and amount generated within the order?
SELECT  Category, round(Sum( Amount),1) AS Total_order_made_within_city, Ship_City FROM amazon_merged_data 
GROUP BY 1
ORDER BY Total_order_made_within_city DESC
LIMIT 10;


#3.  What all appreals are famous within the city of India and amount generated within the order?
SELECT  Category, round(Sum( Amount),1) AS Total_order_made_within_state, Ship_State FROM amazon_merged_data 
GROUP BY 1
ORDER BY Total_order_made_within_state DESC
LIMIT 10;

#4. What types of clothing are popular in the region, and what sizes and color are customers interested in?
SELECT  Category,count(*) AS Total_Order_Made, Size,Color, Ship_State FROM amazon_merged_data 
GROUP BY 1,3
LIMIT 10;

#5What is the avg price of apparels in the states?
SELECT  Category,AVG(Amount) AS Avg_Price, Size,Color, Ship_State FROM amazon_merged_data 
GROUP BY 1,3
ORDER BY Avg_price DESC
LIMIT 10;

SELECT  Category,ROUND(AVG(Amount),1) AS Avg_Price,  Ship_State FROM amazon_merged_data 
GROUP BY 1,3
ORDER BY Avg_price DESC
LIMIT 10;

#6 What percentage of Amazon customer have utilised each service mode?
SELECT
    `Ship-Service-Level`,
    COUNT(*) AS Total_Customers,
    ROUND((COUNT(*) * 100.0) / (SELECT COUNT(*) FROM amazon_merged_data), 2) AS Percentage
FROM
    amazon_merged_data
GROUP BY
    `Ship-Service-Level`;
    
    
    
    







