create database datawarehousefinalproject;

-- Create the Members Dimension Table
CREATE TABLE Members (
    member_id INT PRIMARY KEY,
    member_first_name VARCHAR(100),
    member_last_name VARCHAR(100),
    member_birth_date DATE,
    member_age INT,
    member_gender CHAR(1)
);

-- Insert data into the Members Dimension Table
INSERT INTO Members (member_id, member_first_name, member_last_name, member_birth_date, member_age, member_gender)
VALUES
    (10001, 'David', 'Dennison', '1946-06-14', 72, 'M'),
    (10002, 'John', 'Smith', '1962-01-02', 56, 'M'),
    (10003, 'Jane', 'Doe', '1982-05-04', 36, 'F'),
    (10004, 'Elaine', 'Rogers', '1983-10-12', 34, 'F');

-- Create the Drugs Dimension Table
CREATE TABLE Drugs (
    drug_ndc INT PRIMARY KEY,
    drug_name VARCHAR(100),
    drug_form_code CHAR(2),
    drug_form_desc VARCHAR(100),
    drug_brand_generic_code INT,
    drug_brand_generic_desc VARCHAR(10)
);

-- Insert data into the Drugs Dimension Table
INSERT INTO Drugs (drug_ndc, drug_name, drug_form_code, drug_form_desc, drug_brand_generic_code, drug_brand_generic_desc)
VALUES
    (433530848, 'Risperidone', 'TB', 'Tablet', 1, 'Generic'),
    (545695193, 'Amoxicillin', 'OS', 'Oral Solution', 1, 'Generic'),
    (545693828, 'Ambien', 'TB', 'Tablet', 2, 'Brand'),
    (185085302, 'Diprosone', 'TC', 'Topical Cream', 1, 'Generic');

-- Create the Drug Fill Fact Table
CREATE TABLE DrugFillFact (
    fill_id INT PRIMARY KEY,
    member_id INT,
    drug_ndc INT,
    fill_date DATE,
    copay DECIMAL(10, 2),
    insurance_paid DECIMAL(10, 2),
    FOREIGN KEY (member_id) REFERENCES Members(member_id) ON DELETE CASCADE ON UPDATE CASCADE,
    FOREIGN KEY (drug_ndc) REFERENCES Drugs(drug_ndc) ON DELETE SET NULL ON UPDATE SET NULL
);

-- Insert data into the Drug Fill Fact Table
INSERT INTO DrugFillFact (fill_id, member_id, drug_ndc, fill_date, copay, insurance_paid)
VALUES
    (1, 10001, 433530848, '2017-10-31', 15.00, 50.00),
    (2, 10001, 433530848, '2018-02-22', 15.00, 48.00),
    (3, 10001, 433530848, '2018-05-08', 15.00, 55.00),
    (4, 10002, 545695193, '2018-06-14', 50.00, 130.00),
    (5, 10003, 545693828, '2017-12-30', 35.00, 250.00),
    (6, 10003, 545693828, '2018-05-16', 35.00, 322.00),
    (7, 10004, 185085302, '2017-11-09', 15.00, 600.00),
    (8, 10004, 185085302, '2017-12-08', 15.00, 712.00),
    (9, 10001, 545693828, '2018-01-15', 20.00, 650.00),
    (10, 10001, 545693828, '2018-02-14', 20.00, 648.00),
    (11, 10001, 545693828, '2018-03-13', 20.00, 648.00);


-- Tasks in Part3.
-- 1. Write a SQL query that identifies the number of prescriptions grouped by drug name. 
#Paste your output to this query in the space below here; 
SELECT drug_name, COUNT(*) AS num_prescriptions
FROM DrugFillFact
JOIN Drugs ON DrugFillFact.drug_ndc = Drugs.drug_ndc
GROUP BY drug_name;

-- 2. How many prescriptions were filled for the drug Ambien?
SELECT drug_name, COUNT(*) AS num_prescriptions
FROM DrugFillFact
JOIN Drugs ON DrugFillFact.drug_ndc = Drugs.drug_ndc
WHERE drug_name = 'Ambien';



-- 3. Write a SQL query that counts total prescriptions, counts unique (i.e. distinct) members, sums copay, sums insurance paid, for members grouped as either ‘age 65+’ or ’ < 65’. 
SELECT
    CASE WHEN Members.member_age >= 65 THEN 'age 65+' ELSE '< 65'
    END AS age_group,
    COUNT(DISTINCT DrugFillFact.fill_id) AS total_prescriptions,
    COUNT(DISTINCT Members.member_id) AS unique_members,
    SUM(DrugFillFact.copay) AS total_copay,
    SUM(DrugFillFact.insurance_paid) AS total_insurance_paid
FROM DrugFillFact
JOIN Members ON DrugFillFact.member_id = Members.member_id
GROUP BY age_group;

-- 4. Also answer these questions:
-- How many unique members are over 65 years of age? 
-- How many prescriptions did they fill?

SELECT
    COUNT(DISTINCT Members.member_id) AS unique_members_over_65,
    COUNT(DISTINCT DrugFillFact.fill_id) AS prescriptions_filled_by_over_65
FROM DrugFillFact
JOIN Members ON DrugFillFact.member_id = Members.member_id
WHERE Members.member_age >= 65;

-- 5. Write a SQL query that identifies the amount paid by the insurance for the most recent prescription fill date. Use the format that we learned with SQL Window functions. Your output should be a table with member_id, member_first_name, member_last_name, drug_name, fill_date (most recent), and most recent insurance paid. Paste your output in the space below here; your code should be included in your .sql file.
WITH RankedFills AS ( SELECT m.member_id, m.member_first_name, m.member_last_name, d.drug_name,
        df.fill_date, df.insurance_paid,
        ROW_NUMBER() OVER (PARTITION BY m.member_id ORDER BY df.fill_date DESC) AS rn
    FROM DrugFillFact df
    JOIN Members m ON df.member_id = m.member_id
    JOIN Drugs d ON df.drug_ndc = d.drug_ndc
)
SELECT member_id, member_first_name, member_last_name, drug_name, fill_date, insurance_paid
FROM RankedFills
WHERE rn = 1;

-- 6. Also answer these questions:
-- For member ID 10003, what was the drug name listed on their most recent fill date?
-- How much did their insurance pay for that medication?

WITH RankedFills AS ( SELECT m.member_id, m.member_first_name, m.member_last_name, d.drug_name, 
		df.fill_date, df.insurance_paid,
        ROW_NUMBER() OVER (PARTITION BY m.member_id ORDER BY df.fill_date DESC) AS rn
    FROM DrugFillFact df JOIN Members m ON df.member_id = m.member_id JOIN Drugs d 
    ON df.drug_ndc = d.drug_ndc)
SELECT member_id, member_first_name, member_last_name, drug_name, fill_date, insurance_paid
FROM RankedFills WHERE rn = 1 AND member_id = 10003;
