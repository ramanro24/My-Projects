create database Hiv;
use  Hiv;

select * from hiv_anc_testing_2022;

#Total records in hiv_anc_testing_2022 of pregnant woman
select count(*) from hiv_anc_testing_2022;


#Selecting region Latin america and carribean
select * from hiv_anc_testing_2022
where UNICEF_Region LIKE 'Latin America and Caribbean'
order by Value desc;

#Selecting  Hiv continamintaion in pregnant woman in the year 2015 for country like Argentina
select Value, Country,UNICEF_Region, Year from  hiv_anc_testing_2022
where UNICEF_Region LIKE 'Latin America and Caribbean'
AND Country like 'Argentina' AND Year =2015;

select sum(Value)  from  hiv_anc_testing_2022
where UNICEF_Region LIKE 'Latin America and Caribbean'
AND Country like 'Argentina' AND Year =2015;



#Total Hiv infection found among the pregnant woman  from 2015 till date;
select round(sum(value),0) from  hiv_anc_testing_2022
where UNICEF_Region LIKE 'Latin America and Caribbean';

# Hiv infention found in woman in the year 2015 among the woman
select sum(value) from hiv_anc_testing_2022
where UNICEF_Region LIKE 'Latin America and Caribbean' AND year = 2017;

#Overview of the infection table of infants.
select * from hiv_early_infant_diagnosis_2022
where UNICEF_Region LIKE 'Latin America and Caribbean';

#Total HIV positive case found in the infants.

select sum(value) from  hiv_early_infant_diagnosis_2022
where UNICEF_Region LIKE 'Latin America and Caribbean';

#Total Hiv case in infants in belize till date 

select round(sum(Value),0) as Total_Infection_for_infant_in_Belize  from  hiv_early_infant_diagnosis_2022
where UNICEF_Region LIKE 'Latin America and Caribbean'And Country 
like 'Belize';


#Total Hiv case in infants in belize for the year 2016 

select round(sum(Value),0) as Total_Infection_for_infant_in_Belize_for_2016  from  hiv_early_infant_diagnosis_2022
where UNICEF_Region LIKE 'Latin America and Caribbean'And Country 
like 'Belize' and year = 2016;


#Selecting all data from hiv_prevention_adolescents_2022
select *  from  hiv_prevention_adolescents_2022
where (UNICEF_Region LIKE 'Latin America and Caribbean') and age like '15-49';

#Selecting all data from hiv_prevention_adolescents_2022 from age 15-24;
select *  from  hiv_prevention_adolescents_2022
where (UNICEF_Region LIKE 'Latin America and Caribbean') and age like '15-24';

#Total hiv prevention in the adolescent in latin America and carribean between age 15-49.
select round(sum(Value),0) as Total_HIV_prevention_in_adolescent from  hiv_prevention_adolescents_2022
where (UNICEF_Region LIKE 'Latin America and Caribbean') and age like '15-49';

#HIV Total coverage for for the adoloscent from age 10-14 from year 2010-2022 .

select sum(Value) from hiv_adolescent_art_coverage_2022 where UNICEF_Region like 'Latin America and Caribbean' and Age like 'Age 10-14';

#Hiv Total coverage for Female adoloscent from age 10-14 from 2010-2022
SELECT (sum(Value)/142150)*100 AS Percentage_of_ART_Coverage_for_female 
from hiv_adolescent_art_coverage_2022 
where UNICEF_Region like 'Latin America and Caribbean' 
AND Age LIKE 'Age 10-14' AND sex LIKE 'Female';

#Subquery
#Percentage of Antiretrovial Treatment among female adoloscent aged 10-14.
SELECT round((sum(Value)/(select sum(Value) from hiv_adolescent_art_coverage_2022 where UNICEF_Region like 'Latin America and Caribbean' and Age like 'Age 10-14'))*100,2) AS Percentage_of_ART_Coverage_for_female 
from hiv_adolescent_art_coverage_2022 
where UNICEF_Region like 'Latin America and Caribbean' 
AND Age LIKE 'Age 10-14' AND sex LIKE 'Female';

#Percentage of Antiretrovial Treatment among female adoloscnet aged 10-14.

SELECT round((sum(Value)/(select sum(Value) from hiv_adolescent_art_coverage_2022 where UNICEF_Region like 'Latin America and Caribbean' and Age like 'Age 10-14'))*100,2) AS Percentage_of_ART_Coverage_for_male 
from hiv_adolescent_art_coverage_2022 
where UNICEF_Region like 'Latin America and Caribbean' 
AND Age LIKE 'Age 10-14' AND sex LIKE 'male';

#Getting analysis on  the orphan value for the unicef-region of Latin America and caribbean of different adoloscent period using right join,(inequancy in dataset) 
#observation: we dont have orphan value for latin America and carribean because in the latin america section of HIv orphan we have ISO region for Domincan republic, Aergentina, Bahamas, Belize, 
#while for hiv pervention in adolscent we have region like guyana , mexico, paraguy,salvado

Select hiv_orphans_2022.Value as orphan_value,  hiv_prevention_adolescents_2022.UNICEF_Region, hiv_prevention_adolescents_2022.Sex, hiv_prevention_adolescents_2022.Age, hiv_prevention_adolescents_2022.DISAGG_CATEGORY, hiv_prevention_adolescents_2022.DISAGG, hiv_prevention_adolescents_2022.Value
FROM hiv_orphans_2022
Right JOIN hiv_prevention_adolescents_2022
ON hiv_orphans_2022.ISO3 =hiv_prevention_adolescents_2022.ISO3
WHERE hiv_prevention_adolescents_2022.UNICEF_Region LIKE 'Latin America and Caribbean';


select * from hiv_anc_testing_2022;
select * from hiv_prevention_adolescents_2022;

#table join inner join

select hiv_anc_testing_2022.ISO3, hiv_anc_testing_2022.year, hiv_anc_testing_2022.value, 
hiv_prevention_adolescents_2022.Age, hiv_prevention_adolescents_2022.Sex, hiv_prevention_adolescents_2022.DISAGG, hiv_prevention_adolescents_2022.Value,hiv_prevention_adolescents_2022.UNICEF_Region
From hiv_anc_testing_2022
inner join hiv_prevention_adolescents_2022
ON hiv_anc_testing_2022.ISO3 = hiv_prevention_adolescents_2022.ISO3
where age like '15-19' and hiv_prevention_adolescents_2022.UNICEF_Region like 'Latin America and caribbean';

