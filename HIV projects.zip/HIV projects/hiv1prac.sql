create database Itc6000hiv;
use  Itc6000hiv;
select * from hiv_anc_testing_2022;

#Total records of Pregnant woman in hiv_anc_testing_2022 
SELECT count(*) AS Total_records_of_Pregnant_Woman FROM hiv_anc_testing_2022;

#Selecting region for "Latin America And Carribean".
SELECT * FROM hiv_anc_testing_2022
WHERE UNICEF_Region LIKE 'Latin America and Caribbean'
ORDER BY VALUE DESC;


#Total Number Of Pregnant Women infected with HIV in latin America and Caribbean from 2016 till date.

SELECT SUM(value) AS Number_of_pregnant_women_suffered_from_Hiv_till_date 
FROM hiv_anc_testing_2022
WHERE UNICEF_Region LIKE 'Latin America and Caribbean';




# Hiv in pregnant women in the year 2015 for Argentina.

SELECT Value, Country,UNICEF_Region, Year FROM  hiv_anc_testing_2022
WHERE (UNICEF_Region LIKE 'Latin America and Caribbean')
AND (Country LIKE 'Argentina') AND (Year =2015);




#Total Number of Women who got HIV in the year 2015 in Argentina

SELECT SUM(Value) AS Total_Number_Of_Pregnant_Woman_Having_Hiv_In_Argentina  
FROM  hiv_anc_testing_2022
WHERE (UNICEF_Region LIKE 'Latin America and Caribbean')
AND (Country LIKE 'Argentina') AND (Year =2015);




#Total Hiv infection found among the pregnant woman  from 2015 till date;
select round(sum(value),0) from  hiv_anc_testing_2022
where UNICEF_Region LIKE 'Latin America and Caribbean';


#Country in Latin America and caribbean that witnessed maximum HIV case in Pregnant women in one year.

SELECT * FROM hiv_anc_testing_2022
WHERE UNICEF_Region LIKE 'latin America and Caribbean'
ORDER BY Value DESC;


#Country with maximum number of hiv case among pregnant women for 2018
SELECT * FROM hiv_anc_testing_2022
WHERE UNICEF_Region LIKE 'latin America and Caribbean' and year =2018 
ORDER BY Value DESC;


#Total HIV Case among Pregnant Women in the year 2018
SELECT sum(value) from hiv_anc_testing_2022
WHERE UNICEF_Region LIKE 'latin America and Caribbean' and year =2018 ;

#Contribution in percentage of  HIV Case in pregnant women in Mexico for the year 2018
SELECT ROUND(SUM(value)/(SELECT SUM(value) FROM hiv_anc_testing_2022 
WHERE UNICEF_Region LIKE 'latin America and Caribbean' AND year =2018) *100,2)
AS Percentage_of_HIV_contamination_contributed_by_Mexican_women_in_2018
FROM hiv_anc_testing_2022
WHERE (UNICEF_Region LIKE 'latin America and Caribbean') AND (year =2018) AND (country like 'Mexico');




# Hiv infection found in woman in the year 2015 among the woman
select sum(value) from hiv_anc_testing_2022
where UNICEF_Region LIKE 'Latin America and Caribbean' AND year = 2017;

#Total number of infants who got hiv form mother form 2016-2022
select sum(value) As total_infants_who_got_hiv_in_latin_America_caribbean from hiv_early_infant_diagnosis_2022
WHERE (UNICEF_Region LIKE 'Latin America and Caribbean')
AND Year IN (2016, 2017,2018,2019,2020,2021,2022)
ORDER BY value DESC;

# Percentage of Infants who got HIV from mother in the Latin America and Caribbean.
#Percentage of Infants who got HIV from the mother during pregnancy
#Here 41553 is the total number of infants who got hiv from mother during pregnancy in latina america and caribbean region 
#from year 2016-2022
SELECT ISO3, Type, Country, Unicef_Region, Year,ROUND((((Value)/41553)*100),2)  
AS Percentage_of_Infants_who_got_hiv_from_mother_during_pregnancy
FROM hiv_early_infant_diagnosis_2022
WHERE (UNICEF_Region LIKE 'Latin America and Caribbean')
AND Year IN (2016, 2017,2018,2019,2020,2021,2022)
ORDER BY Percentage_of_Infants_who_got_hiv_from_mother_during_pregnancy DESC;

#Total HIV positive case found in the infants.

select sum(value) from  hiv_early_infant_diagnosis_2022
where UNICEF_Region LIKE 'Latin America and Caribbean';

#Total Hiv case in infants in belize till date 

select round(sum(Value),0) as Total_Infection_for_infant_in_Belize  from  hiv_early_infant_diagnosis_2022
where UNICEF_Region LIKE 'Latin America and Caribbean'And Country 
like 'Belize';


#Total Hiv case in infants in CUBA for the year 2016,2017,2018 

SELECT ROUND(SUM(Value),0) AS Total_Infection_for_infant_in_Cuba_for_2016_2017_2018  
FROM  hiv_early_infant_diagnosis_2022
WHERE (UNICEF_Region LIKE 'Latin America and Caribbean')AND (Country 
LIKE 'Cuba') AND (year IN (2016,2017,2018));


#Selecting all data from hiv_prevention_adolescents_2022
select *  from  hiv_prevention_adolescents_2022
where (UNICEF_Region LIKE 'Latin America and Caribbean') and age like '15-49';
#---------------------------------------------------------------------------------------------------
#Selecting all data from hiv_prevention_adolescents_2022 from age 15-24;
select *  from  hiv_prevention_adolescents_2022
where (UNICEF_Region LIKE 'Latin America and Caribbean') and age like '15-24';

#Total hiv prevention in the adolescent in latin America and carribean between age 15-49.
select round(sum(Value),0) as Total_HIV_prevention_in_adolescent from  hiv_prevention_adolescents_2022
where (UNICEF_Region LIKE 'Latin America and Caribbean') and age like '15-49';

#HIV Total coverage for for the adoloscent from age 10-14 from year 2010-2022 .

select sum(Value) from hiv_adolescent_art_coverage_2022 where UNICEF_Region like 'Latin America and Caribbean' and Age like 'Age 10-14';

#Hiv Total coverage for Female adoloscent from age 10-14 from 2010-2022
SELECT (sum(Value)/142150)*100 AS Percentage_of_ART_Coverage_for_female 
from hiv_adolescent_art_coverage_2022 
where UNICEF_Region like 'Latin America and Caribbean' 
AND Age LIKE 'Age 10-14' AND sex LIKE 'Female';

#Subquery Demonstration.
#Percentage of female adolescent receiving ART(Antiretrovial Coverage ).
SELECT round((sum(Value)/(SELECT sum(Value) FROM hiv_adolescent_art_coverage_2022 WHERE
UNICEF_Region LIKE 'Latin America and Caribbean' AND Age LIKE 'Age 10-14'))*100,2) 
AS Percentage_of_female_adolescent_receiving_ART_Coverage
FROM hiv_adolescent_art_coverage_2022 
WHERE UNICEF_Region LIKE 'Latin America and Caribbean' 
AND Age LIKE 'Age 10-14' AND sex LIKE 'Female';



#Percentage of  female adolescent receiving ART(Antiretrovial Coverage ).

SELECT round((sum(Value)/(select sum(Value) from hiv_adolescent_art_coverage_2022 where UNICEF_Region like 'Latin America and Caribbean' and Age like 'Age 10-14'))*100,2) AS Percentage_of_ART_Coverage_for_male 
from hiv_adolescent_art_coverage_2022 
where UNICEF_Region like 'Latin America and Caribbean' 
AND Age LIKE 'Age 10-14' AND sex LIKE 'male';






#Country with higest fraction of Orphan either male or female who is living in orphange getting comprehensive knowledge on HIV
#trasmission.
SELECT  hiv_prevention_adolescents_2022.Country, hiv_prevention_adolescents_2022.UNICEF_Region, 
hiv_prevention_adolescents_2022.Sex, hiv_prevention_adolescents_2022.Year,
hiv_prevention_adolescents_2022.Value AS number_of_adoloscent_reciving_knowledge,
hiv_orphans_2022.Value AS orphan_value, ROUND(((hiv_prevention_adolescents_2022.Value/hiv_orphans_2022.Value)),2) AS
Fraction_of_orphan_reciving_knowledge_On_HIV FROM hiv_orphans_2022 
LEFT JOIN hiv_prevention_adolescents_2022 ON hiv_orphans_2022.ISO3 =hiv_prevention_adolescents_2022.ISO3
WHERE hiv_prevention_adolescents_2022.Country like "Colombia"
GROUP BY Country;


select * from hiv_anc_testing_2022;
select * from hiv_prevention_adolescents_2022;
----------------------------------------------------------------------------------------------------------
#Table join inner join


select hiv_anc_testing_2022.ISO3,hiv_prevention_adolescents_2022.UNICEF_Region, hiv_anc_testing_2022.year, hiv_anc_testing_2022.value As pregnant_woman_with_Hiv, 
hiv_prevention_adolescents_2022.Age As adolescent_age, hiv_prevention_adolescents_2022.Sex as Adol_Gender,hiv_prevention_adolescents_2022.DISAGG_CATEGORY, hiv_prevention_adolescents_2022.Value adolescent_value,  hiv_prevention_adolescents_2022.DISAGG
From hiv_anc_testing_2022
inner join hiv_prevention_adolescents_2022
ON hiv_anc_testing_2022.ISO3 = hiv_prevention_adolescents_2022.ISO3
where age like '15-19' and hiv_prevention_adolescents_2022.UNICEF_Region like 'Latin America and caribbean';

# Table merge demonstration list 
#No Transmission of HIV FROM Mother to Male children(gender=Male) for the year 2017 in 
#Latin America And Caribbean Region.
SELECT hiv_anc_testing_2022.year,hiv_anc_testing_2022.value AS woman_infected_with_Hiv, 
hiv_prevention_adolescents_2022.Sex AS Adol_Gender,
hiv_prevention_adolescents_2022.Value AS percent_of_adolescent_Not_having_Hiv,
hiv_prevention_adolescents_2022.Age AS adolescent_age
FROM hiv_anc_testing_2022
INNER JOIN hiv_prevention_adolescents_2022
ON hiv_anc_testing_2022.ISO3 = hiv_prevention_adolescents_2022.ISO3
WHERE (hiv_prevention_adolescents_2022.UNICEF_Region LIKE 'Latin America and caribbean')
AND(hiv_prevention_adolescents_2022.Sex like "Male") AND (hiv_anc_testing_2022.year = 2017) AND 
(hiv_prevention_adolescents_2022.Age like '15-19')
GROUP BY year;


#No Transmission of HIV From Mother to Male children for the year 2017 in 
#Latin America And Caribbean Region.
SELECT hiv_anc_testing_2022.year,hiv_anc_testing_2022.value AS woman_infected_with_Hiv,
hiv_prevention_adolescents_2022.Sex AS Adol_Gender,
hiv_prevention_adolescents_2022.Value AS adolescent_Not_having_Hiv
FROM hiv_anc_testing_2022
INNER JOIN hiv_prevention_adolescents_2022
ON hiv_anc_testing_2022.ISO3 = hiv_prevention_adolescents_2022.ISO3
WHERE (hiv_prevention_adolescents_2022.UNICEF_Region like 'Latin America and caribbean') 
AND (hiv_prevention_adolescents_2022.Sex like "Male") AND (hiv_anc_testing_2022.year = 2017)
AND (hiv_prevention_adolescents_2022.Age like '15-19')
group by year;

#Orphan adoloscent who is facing discriminatory in the Latin America And Carribean Region
#Observation- We got to know 1 out of 3 Adoloscent faces discriminatory.
select hiv_orphans_2022.UNICEF_Region, hiv_orphans_2022.year, hiv_discrimination_2022.sex, 
hiv_discrimination_2022.Age, hiv_orphans_2022.Value as Adolescent_living_in_Orphan,
hiv_discrimination_2022.Value as percentage_who_faced_descriminatory
from hiv_orphans_2022
inner join hiv_discrimination_2022
on hiv_orphans_2022.ISO3 =hiv_discrimination_2022.ISO3
where hiv_orphans_2022.UNICEF_Region like 'Latin America and Caribbean'
group by UNICEF_Region;

#Percentage of women who is suffering from HIV and percentage of it receiving coverage 
#for the prevention of mother to child tranmisson in all the year.

SELECT hiv_anc_testing_2022.UNICEF_Region, hiv_anc_testing_2022.Year, 
hiv_anc_testing_2022.value AS Percentage_Of_Women_diagonsed_with_hiv, 
hiv_pmtct_coverage_2022.value AS Percentage_of_women_receiving_PMCTC
FROM hiv_anc_testing_2022
RIGHT JOIN hiv_pmtct_coverage_2022
ON hiv_anc_testing_2022.ISO3 =hiv_pmtct_coverage_2022.ISO3
WHERE hiv_anc_testing_2022.UNICEF_Region LIKE 'Latin America and Caribbean'
GROUP BY year;



